@extends('partials.layout')
@section('content')
<div class="hero bg-base-200 min-h-screen">
    <div class="hero-content text-center">
      <div class="max-w-md">
        <h1 class="text-5xl font-bold">You're logged in!</h1>
      </div>
    </div>
  </div>

     
@endsection
